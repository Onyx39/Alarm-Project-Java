import java.time.*;

public class Incendie extends AnomalieEvent {

    public Incendie(LocalDate uneDate, String unLieu, Integer unNiveau) {
        super(uneDate, unLieu, unNiveau);
    }


}