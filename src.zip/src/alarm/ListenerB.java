public interface ListenerB extends Listener {

    public void onEvent (EmissionRadiation e);
    
}
