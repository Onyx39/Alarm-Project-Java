public interface Listener {

    public void onEvent (EmissionGaz e);
    
}
