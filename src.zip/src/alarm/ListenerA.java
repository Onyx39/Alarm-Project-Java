public interface ListenerA  extends Listener {

    public void onEvent (Incendie e);
    
}