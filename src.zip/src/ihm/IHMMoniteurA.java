package ihm;


import alarm.EmissionGaz;
import alarm.Incendie;
import alarm.ListenerA;


import java.util.ArrayList;

import javax.swing.DefaultListModel;
import javax.swing.JFrame;
import javax.swing.JList;

public class IHMMoniteurA extends JFrame implements ListenerA {

    final JFrame f = new JFrame("Interface moniteur type A");

    DefaultListModel<String> l1 = new DefaultListModel<>();  
    JList<String> list1 = new JList<>(l1);
    
    list1.setBounds(0, 42, 100,54);

    final JButton details = new JButton("Détails");
    
    f.add(details);
    f.add(list1);
    

    public void onEvent (EmissionGaz e) {
        list1.add("Alerte gaz", null);
        SwingUtilities.updateComponentTreeUI(f);
    }

    public void onEvent (Incendie e) {
        list1.add("Alerte feu", null);
        SwingUtilities.updateComponentTreeUI(f);
    }

    
    

}